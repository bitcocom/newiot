package com.example.myapplication;

import androidx.annotation.Nullable;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class LEDSensor extends StringRequest {
    // nodejs에 요청하는 URL
    final static String URL="http://172.30.1.44:3000/devices/led";  // "flag"="on"
    private Map<String, String> parameters;
    public LEDSensor(String led, Response.Listener<String> listener) {
        super(Method.POST, URL, listener, null); // 요청되는 부분
        parameters=new HashMap<String, String>();
        parameters.put("flag", led);
    }
    @Override
    protected Map<String,String> getParams(){
        return parameters;
    }
}
